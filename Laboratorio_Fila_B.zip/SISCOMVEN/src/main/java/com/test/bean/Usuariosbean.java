/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

import com.test.conexion.VariablesConexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.annotation.PreDestroy;

/**
 *
 * @author SmartUrban2025
 */

public class Usuariosbean {
    private Connection con;
    private VariablesConexion var;
    public Usuariosbean() throws SQLException{
        var = new VariablesConexion();
        var.inicioConexion();
        con = var.getConnection();
        System.out.println("Iniciando la Conexion...!!! ");
    }
    
    @PreDestroy
    public void cerrarConexion(){
        var.cerrarConexion();
    }
    public String buscarUser(String user){
        StringBuilder salidaTabla=new StringBuilder();
        StringBuilder query=new StringBuilder();
        query.append(" SELECT e.ci,  CONCAT(e.nombre,' ', e.paterno, ' ', e.materno) AS nombre, u.usuario, c.cargo, u.nivel FROM usuarios u INNER JOIN empleado e ON u.id_empleado = e.id_empleado INNER JOIN cargo c ON c.id_cargo = e.id_cargo WHERE c.cargo =  ");
        query.append("'"+user+"'");
        try {
            PreparedStatement pst=con.prepareStatement(query.toString());
            ResultSet resultado=pst.executeQuery();
            while(resultado.next()){
                salidaTabla.append("<tr>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getInt(1));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(2));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(3));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(4));
                salidaTabla.append("</td>");
                salidaTabla.append("</tr>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error de conexion");
        }
        return salidaTabla.toString();
    }
}