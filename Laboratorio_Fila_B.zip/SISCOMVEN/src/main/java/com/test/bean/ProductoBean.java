/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

import com.test.conexion.VariablesConexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.annotation.PreDestroy;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author SmartUrban2025
 */

public class ProductoBean {
    private Connection connection;
    private PreparedStatement insertProductos;
    private VariablesConexion variable;
    public ProductoBean()throws SQLException{
        variable=new VariablesConexion();
        variable.inicioConexion();
        connection=variable.getConnection();
        System.out.println("Iniciando la conexion");
    }
 
     @PreDestroy
    public void cerrarConexion(){
        variable.cerrarConexion();
    }
    public String registrarproductos(HttpServletRequest request){
        String mensaje="";
        if(request==null){
            return"";
        }
        if(connection!=null){
            try {
                StringBuilder query=new StringBuilder();
                query.append(" insert into productos ");
                query.append(" values (?,?,?,?,?,?,?)");
                if(insertProductos==null){
                    insertProductos=connection.prepareStatement(query.toString());
                }
                String proveedor_id_proveedor=request.getParameter("prove");
                String nombreproducto=request.getParameter("nombre");
                String precio_unitario=request.getParameter("p_u");
                String fecha_vencimiento=request.getParameter("f_v");
                String tipo_producto=request.getParameter("t_p");
                String stock=request.getParameter("stock");
                float p_u=Float.parseFloat(precio_unitario);
                int pro=Integer.parseInt(proveedor_id_proveedor);
                insertProductos.setString(1,null);
                insertProductos.setInt(2,pro);
                insertProductos.setString(3,nombreproducto);
                insertProductos.setFloat(4,p_u);
                insertProductos.setString(5,fecha_vencimiento);
                insertProductos.setString(6,tipo_producto);
                insertProductos.setString(7,stock);
                mensaje=insertProductos.toString();
                int registro=insertProductos.executeUpdate();
                if(registro==1){
                    mensaje="Registro realizado con exito";
                }else{
                    mensaje="Error al insertar el registro";
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return mensaje;
     }
    
    public String listaProducto(){
        StringBuilder salidaTabla=new StringBuilder();
        StringBuilder query=new StringBuilder();
        query.append("SELECT p.id_producto, pr.empresa FROM producto p INNER JOIN proveedor pr ON p.id_proveedor = pr.id_proveedor");
        try {
            PreparedStatement pst=connection.prepareStatement(query.toString());
            ResultSet resultado=pst.executeQuery();
            while(resultado.next()){
                salidaTabla.append("<tr>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getInt(1));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(2));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(3));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(4));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(5));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(6));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(7));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(8));
                salidaTabla.append("</td>");
                
                salidaTabla.append("</tr>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error de conexion");
        }
        return salidaTabla.toString();
    }
    
        public String listaProveedor(){
        StringBuilder salida= new StringBuilder();
        StringBuilder query = new StringBuilder();
        query.append(" select p.id_proveedor, p.empresa from proveedor p ");
        try {
            PreparedStatement pst = connection.prepareStatement(query.toString());
            ResultSet resultado = pst.executeQuery();
            while (resultado.next()) {           
                salida.append("<option value='");
                salida.append(resultado.getInt(1));
                salida.append("'>");
                salida.append(resultado.getString(2));
                salida.append("</option>");
            }
            System.out.println("EXITO");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error de Conexion!");
        }
        return salida.toString();
    }

     public String lista_producto_proveedor(String codigo_nombreprov){
        StringBuilder salidaTabla=new StringBuilder();
        StringBuilder query=new StringBuilder();
        query.append(" select u.id_productos, e.empresa , u.nombreproducto, u.precio_unitario, u.fecha_vencimiento, u.tipo_producto, u.stock");
        query.append(" from productos u ");
        query.append(" inner join proveedor e on u.proveedor_id_proveedor = e.id_proveedor ");
        query.append(" where e.id_proveedor =  "+codigo_nombreprov);
        try {
            PreparedStatement pst=connection.prepareStatement(query.toString());
            ResultSet resultado=pst.executeQuery();
            while(resultado.next()){
                salidaTabla.append("<tr>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getInt(1));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(2));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(3));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(4));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(5));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(6));
                salidaTabla.append("</td>");
                salidaTabla.append("<td>");
                salidaTabla.append(resultado.getString(7));
                salidaTabla.append("</td>");
                salidaTabla.append("</tr>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error de conexion");
        }
        return salidaTabla.toString();
    }
}